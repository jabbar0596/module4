package pak1;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class NewTab {
	static String driverpath = "D:\\VNV Software\\Selenium\\WebDrivers\\";
	public static void main(String[] args) throws InterruptedException 
	{
		
	// 1.Launch Browser
	System.setProperty("webdriver.chrome.driver", driverpath+ "chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	driver.get("file:///D:/Participants%20Material/Module%204/Demos/Lesson%205-HTML%20Pages/PopupWin.html");
	Thread.sleep(2000);
	//driver.findElement(By.name("btnAlert")).click();
	//Store parent window id
	String parent_window = driver.getWindowHandle();
	System.out.println(parent_window);
	//click on Open Window button
	driver.findElement(By.name("Open")).click();
	Thread.sleep(2000);
	
	//Switching from parent window to child
	Set<String> s1 = driver.getWindowHandles();
	Iterator<String> it = s1.iterator();
	while(it.hasNext())
	{
		String child_window = it.next();
		if(!parent_window.equalsIgnoreCase(child_window))
		{
			System.out.println(child_window);
			//switching form parent to child window
			driver.switchTo().window(child_window);
			Thread.sleep(5000);
			//Performing actions on child window
			driver.findElement(By.id("lst-ib")).sendKeys("Selenium");
			driver.findElement(By.cssSelector("input[value='Google Search']")).click();
			Thread.sleep(2000);
			driver.navigate().to("https://www.google.co.in/imghp?hl=en&tab=wi");
			driver.findElement(By.id("lst-ib")).sendKeys("Dragon Ball Z");
			Thread.sleep(2000);
			
			driver.navigate().to("https://www.google.co.in/search?hl=en&tbm=isch&source=hp&biw=1024&bih=734&ei=o9heWqWvAZH08AXa-KzoCw&q=Dragon+Ball+Z&oq=Dragon+Ball+Z&gs_l=img.12..0l10.126249.131296.0.159660.15.12.1.0.0.0.372.2254.2-2j5.7.0....0...1ac.1.64.img..7.8.2257....0.vV7XEVPJod8&safe=active");
			Thread.sleep(3000);
			driver.close();
		}
	}
	//Switching back to Parent Window
	Thread.sleep(3000);
	driver.switchTo().window(parent_window);
	driver.close();
	
	}
}