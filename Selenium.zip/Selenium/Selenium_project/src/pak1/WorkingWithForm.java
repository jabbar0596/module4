package pak1;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WorkingWithForm {
static String driverpath = "D:\\VNV Software\\Selenium\\WebDrivers\\";
	public static void main(String[] args) 
	{
	
	// 1.Launch Browser
	System.setProperty("webdriver.chrome.driver", driverpath+ "chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	
	// 2.Navigate to URL
	driver.get("file:///D:/Participants%20Material/Module%204/Demos/Lesson%205-HTML%20Pages/WorkingWithForms.html");
	
	// 3.Enter Name
	driver.findElement(By.id("txtUserName")).sendKeys("PriyalPotnis");;
	driver.findElement(By.id("txtPassword")).sendKeys("abcd");
	driver.findElement(By.id("txtConfPassword")).sendKeys("abcd");
	driver.findElement(By.id("txtFirstName")).sendKeys("Priyal");
	driver.findElement(By.id("txtLastName")).sendKeys("Potnis");
	driver.findElement(By.id("rbMale")).click();
	driver.findElement(By.id("DOB")).sendKeys("05/17/1995");
	driver.findElement(By.id("txtEmail")).sendKeys("priyal@gmail.com");
	driver.findElement(By.id("txtAddress")).sendKeys("Priyal Kingdom");
	driver.findElement(By.xpath("//option[@value='Bangalore']")).click();
	driver.findElement(By.id("txtPhone")).sendKeys("9930876234");
	driver.findElement(By.xpath("//input[@value='Reading']")).click();
	//driver.findElement(By.xpath("//input[@value='Movies']")).click();
	driver.findElement(By.cssSelector("input[value='Music']")).click();
	//driver.findElement(By.name("submit")).submit();
	
	}
	
}
