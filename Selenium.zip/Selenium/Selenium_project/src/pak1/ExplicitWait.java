package pak1;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ExplicitWait {
	static String driverpath = "D:\\VNV Software\\Selenium\\WebDrivers\\";
	public static void main(String[] args) throws InterruptedException 
	{
		
	// 1.Launch Browser
	System.setProperty("webdriver.chrome.driver", driverpath+ "chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	driver.get("file:///D:/Participants%20Material/Module%204/Demos/Lesson%205-HTML%20Pages/AlertExample.html");
	driver.findElement(By.name("btnAlert")).click();
	
	//to check if alert present
	WebDriverWait wait = new WebDriverWait(driver,10);
	wait.until(ExpectedConditions.alertIsPresent());
	//Switching to alert
	Alert alt = driver.switchTo().alert();
	//fetch the txt of alert
	System.out.println(alt.getText());
	//to perform action on alert
	//to click on Ok button
	//alt.accept();
	//to esc alert
	alt.dismiss();
	
	
	
	}

}
