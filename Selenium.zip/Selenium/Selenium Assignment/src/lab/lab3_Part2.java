//Automate and Validate the different sections of 'Register Account' page:
package lab;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;

public class lab3_Part2 
{
	static String driverpath = "D:\\VNV Software\\Selenium\\WebDrivers\\";
	public static void main(String[] args) throws InterruptedException 
	{
		// TODO Auto-generated method stub
		// 1.Launch Browser
		System.setProperty("webdriver.chrome.driver", driverpath+ "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		
		//WebDriver driver = new FirefoxDriver();
		driver.get("https://demo.opencart.com/");
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.linkText("Register")).click();	
		
		/******************---PART 2--- For 'Your Personal Details'*********************************************/
		driver.findElement(By.name("agree")).click();
		//1. Enter data in 'First Name' text box
		driver.findElement(By.id("input-firstname")).sendKeys("abcdefghijklmnopqrstuvwxyz1234567");
		driver.findElement(By.cssSelector("input[value='Continue']")).click();
		//2. Verify if 33 characters can be entered in firstname
		
		WebElement wb = driver.findElement(By.xpath("//*[@id='account']/div[2]/div/div"));
		String firstName = wb.getText();
        System.out.println(firstName);
        boolean firstName1=firstName.equals("First Name must be between 1 and 32 characters!");
        //System.out.println(firstName.equals("First Name must be between 1 and 32 characters!"));
        //3. if not verify error message
        if(firstName1==true)	
        	System.out.println("First Name is Verified");
        else
        	System.out.println("First Name is Not Verified");
       
        
		driver.findElement(By.cssSelector("input[value='Continue']")).click();
				
		//4. Enter data in 'Last Name' text box
		driver.findElement(By.id("input-lastname")).sendKeys("abcdefghijklmnopqrstuvwxyz1234567");
		
		//5. Verify if 33 characters can be entered in lastname
		WebElement wb2 = driver.findElement(By.xpath("//*[@id='account']/div[3]/div/div"));
		String lastName = wb2.getText();
        System.out.println(lastName);
        
        boolean lastName1=lastName.equals("Last Name must be between 1 and 32 characters!");
        //6. If not verify error message
        if(lastName1==true)	
        System.out.println("Last Name is Verified");
        else
        	System.out.println("Last Name is Not Verified");
		
		//7. Enter valid 'E-mail'.
		driver.findElement(By.id("input-email")).sendKeys("priyal20@gmail.com");
		
		//8. Enter 'Telephone' which must be between 3 and 32 characters
		driver.findElement(By.name("telephone")).sendKeys("9170519950");
		
		driver.findElement(By.cssSelector("input[value='Continue']")).click();
	
	}
}