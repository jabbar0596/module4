package lab;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;

public class lab3_Part1 
{
	static String driverpath = "D:\\VNV Software\\Selenium\\WebDrivers\\";
	public static void main(String[] args) throws InterruptedException 
	{
		// TODO Auto-generated method stub
/******************---PART 1---*********************************************/
		// 1.Launch Browser
		System.setProperty("webdriver.chrome.driver", driverpath+ "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		
		//WebDriver driver = new FirefoxDriver();
		driver.get("https://demo.opencart.com/");
		//part1 1. LaunchApplication
	      //2. Verificaiton of title
	      String expectedTitle = "Your Store";
	      String actualTitle = driver.getTitle();
	      if(expectedTitle.equals(actualTitle))
	    	  System.out.println("Expected title is equal to Actual title");
	      else
	    	  System.out.println("Expected title is not equal to Actual Title");
	      
	      
	      //3. Click on My Account drop down
	      driver.findElement(By.linkText("My Account")).click();
	      
	      //4. select Register from drop down
	      driver.findElement(By.linkText("Register")).click();
	      
	      
	      //5.Verify the heading Register Account
	      String regacc = driver.findElement(By.xpath("//*[@id='content']/h1")).getText();
	      String regacc1 = "Register Account";
	      if(regacc.equals(regacc1))
	    	  System.out.println("Expected heading is equal to actual heading");
	      else
	    	  System.out.println("Expected Heading is not equal to Actual Heading");
	      
	      //6. Click on 'Continue' button at the bottom of the page
	      driver.findElement(By.cssSelector("input[value='Continue']")).click();
	      
	      //7. verify warning message
	      String actualWarn = driver.findElement(By.xpath("html/body/div[2]/div[1]")).getText();
        String expectedWarn = "Warning: You must agree to the Privacy Policy!";
        if(actualWarn.equals(expectedWarn))
      	  System.out.println("Warning is verified");
        else
      	  System.out.println("Warning is not verified");
        
        driver.close();
	}

	
}
