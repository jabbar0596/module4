package lab;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;

public class lab3_Part4 
{
	static String driverpath = "D:\\VNV Software\\Selenium\\WebDrivers\\";
	public static void main(String[] args) throws InterruptedException 
	{
		// TODO Auto-generated method stub
		// 1.Launch Browser
		System.setProperty("webdriver.chrome.driver", driverpath+ "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		
		//WebDriver driver = new FirefoxDriver();
		driver.get("https://demo.opencart.com/");
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.linkText("Register")).click();
	
		driver.findElement(By.xpath("//input[@name='firstname']")).sendKeys("Priyal");
	
		driver.findElement(By.xpath("//input[@id='input-lastname']")).sendKeys("Potnis");
		driver.findElement(By.id("input-email")).sendKeys("priyal90@gmail.com");
		
		driver.findElement(By.name("telephone")).sendKeys("9170519950");

		/**********************PART 4****************************************************************************/
		
		/********FOR 'Password'************/
		//1. Enter 'Password' which must be between 4 and 20 characters.
		driver.findElement(By.id("input-password")).sendKeys("priyal123");
	
		//2. Enter 'Password' Confirm
		driver.findElement(By.cssSelector("input#input-confirm")).sendKeys("priyal123");

		/********FOR 'Newsletter'**********/
		//1. Click on 'Yes' Radio button
		driver.findElement(By.xpath("//*[@id='content']/form/fieldset[3]/div/div/label[1]/input")).click();
		
		//2. Click on checkbox for 'I have read and agree to the Privacy Policy
		driver.findElement(By.name("agree")).click();
		
		//3. Click on 'Continue' button
		driver.findElement(By.cssSelector("input[value='Continue']")).click();

		//4. Verify message 'Your Account Has Been Created!'
		WebElement wb2 = driver.findElement(By.xpath("//*[@id='content']/h1"));
		String expectedtitle = "Your Account Has Been Created!";
		String actualtitle = wb2.getText();
		System.out.println(actualtitle);
		if(expectedtitle.equals(actualtitle)){
			System.out.println("Account has created");
		}
		else{
			System.out.println("Account has not created");
		}
		
		//5. Click on Continue
		driver.findElement(By.xpath("html/body/div[2]/div/div/div/div/a")).click();
		
		 //6. Click on link 'View your order history under 'My orders'
	      driver.findElement(By.xpath("html/body/div[2]/div/div/ul[2]/li[1]/a")).click();

	      //Close Browser
	      driver.close();
	}

	
}
