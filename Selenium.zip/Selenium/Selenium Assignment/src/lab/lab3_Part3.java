package lab;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;
//import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

public class lab3_Part3 
{
	static String driverpath = "D:\\VNV Software\\Selenium\\WebDrivers\\";
	public static void main(String[] args) throws InterruptedException 
	{
		// TODO Auto-generated method stub
		// 1.Launch Browser
		System.setProperty("webdriver.chrome.driver", driverpath+ "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		
		//WebDriver driver = new FirefoxDriver();
		driver.get("https://demo.opencart.com/");
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.linkText("Login")).click();
		driver.findElement(By.id("input-email")).sendKeys("priyal20@gmail.com");
		driver.findElement(By.id("input-password")).sendKeys("priyal123");
		driver.findElement(By.cssSelector("input[value='Login']")).click();
		
		driver.findElement(By.linkText("Modify your address book entries")).click();
		driver.findElement(By.linkText("New Address")).click();
		
        //1. Enter 'Address 1' which should contain characters between 3 and 128
        driver.findElement(By.xpath("//*[@id='input-address-1']")).sendKeys("CapGemini");
        
        //2. Enter 'city' which hould contain characters between 2 and 128
        driver.findElement(By.xpath("//*[@id='input-city']")).sendKeys("Bangalore");
        
        //3. Enter 'post code' which should contain characters between 2 and 10
        driver.findElement(By.id("input-postcode")).sendKeys("523240");
        
        //4. Select 'India' from Country' Drop down
        WebElement country = driver.findElement(By.xpath("//*[@id='input-country']"));
		Select s = new Select(country);
		s.selectByVisibleText("India");
		//s.selectByIndex(99);
		
		//5. Select 'Region/State from dropdown list
    	WebElement region = driver.findElement(By.id("input-zone"));
    	Select s1 = new Select(region);
    	s1.selectByIndex(2);

	}
}